import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() => runApp(MyApp());

const String apiKey = 'SUA_API_KEY_DO_TMDB';
const String baseUrl = 'https://api.themoviedb.org/3';

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Filmes e Séries',
      theme: ThemeData.dark(),
      home: HomePage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _selectedIndex = 0;
  final List<Widget> _pages = [FilmesPage(), SeriesPage()];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.movie), label: 'Filmes'),
          BottomNavigationBarItem(icon: Icon(Icons.tv), label: 'Séries'),
        ],
      ),
    );
  }
}

class FilmesPage extends StatefulWidget {
  @override
  _FilmesPageState createState() => _FilmesPageState();
}

class _FilmesPageState extends State<FilmesPage> {
  List filmes = [];
  TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    buscarFilmes();
  }

  Future<void> buscarFilmes([String? query]) async {
    final url = query == null || query.isEmpty
        ? Uri.parse('$baseUrl/movie/popular?api_key=$apiKey&language=pt-BR')
        : Uri.parse('$baseUrl/search/movie?api_key=$apiKey&language=pt-BR&query=$query');

    final resposta = await http.get(url);

    if (resposta.statusCode == 200) {
      final dados = json.decode(resposta.body);
      setState(() {
        filmes = dados['results'];
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Filmes Populares'),
        bottom: PreferredSize(
          preferredSize: Size.fromHeight(50),
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Buscar filmes...',
                prefixIcon: Icon(Icons.search),
                filled: true,
                fillColor: Colors.white10,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide.none,
                ),
              ),
              onSubmitted: buscarFilmes,
            ),
          ),
        ),
      ),
      body: filmes.isEmpty
          ? Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: filmes.length,
              itemBuilder: (context, index) {
                final filme = filmes[index];
                return ListTile(
                  leading: Image.network(
                    'https://image.tmdb.org/t/p/w200${filme['poster_path']}',
                    fit: BoxFit.cover,
                  ),
                  title: Text(filme['title']),
                  subtitle: Text('Nota: ${filme['vote_average']}'),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => DetalhePage(item: filme, isFilme: true),
                    ),
                  ),
                );
              },
            ),
    );
  }
}

class SeriesPage extends StatefulWidget {
  @override
  _SeriesPageState createState() => _SeriesPageState();
}

class _SeriesPageState extends State<SeriesPage> {
  List series = [];
  TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    buscarSeries();
  }

  Future<void> buscarSeries([String? query]) async {
    final url = query == null || query.isEmpty
        ? Uri.parse('$baseUrl/tv/popular?api_key=$apiKey&language=pt-BR')
        : Uri.parse('$baseUrl/search/tv?api_key=$apiKey&language=pt-BR&query=$query');

    final resposta = await http.get(url);

    if (resposta.statusCode == 200) {
      final dados = json.decode(resposta.body);
      setState(() {
        series = dados['results'];
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Séries Populares'),
        bottom: PreferredSize(
          preferredSize: Size.fromHeight(50),
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Buscar séries...',
                prefixIcon: Icon(Icons.search),
                filled: true,
                fillColor: Colors.white10,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide.none,
                ),
              ),
              onSubmitted: buscarSeries,
            ),
          ),
        ),
      ),
      body: series.isEmpty
          ? Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: series.length,
              itemBuilder: (context, index) {
                final serie = series[index];
                return ListTile(
                  leading: Image.network(
                    'https://image.tmdb.org/t/p/w200${serie['poster_path']}',
                    fit: BoxFit.cover,
                  ),
                  title: Text(serie['name']),
                  subtitle: Text('Nota: ${serie['vote_average']}'),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => DetalhePage(item: serie, isFilme: false),
                    ),
                  ),
                );
              },
            ),
    );
  }
}

class DetalhePage extends StatelessWidget {
  final Map item;
  final bool isFilme;

  DetalhePage({required this.item, required this.isFilme});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(isFilme ? item['title'] : item['name'])),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (item['backdrop_path'] != null)
              Center(
                child: Image.network(
                  'https://image.tmdb.org/t/p/w500${item['backdrop_path']}',
                ),
              ),
            SizedBox(height: 16),
            Text(
              item['overview'] ?? 'Sem descrição disponível.',
              style: TextStyle(fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }
}
